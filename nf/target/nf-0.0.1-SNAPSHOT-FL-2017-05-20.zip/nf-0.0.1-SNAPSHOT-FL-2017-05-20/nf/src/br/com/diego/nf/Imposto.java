package br.com.diego.nf;

public interface Imposto {
	public Double getValor(Double fatura);
}
